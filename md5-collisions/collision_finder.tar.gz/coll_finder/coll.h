#include <stdint.h>

void find_collision(const uint32_t IV[], uint32_t msg1block0[], uint32_t msg1block1[], uint32_t msg2block0[], uint32_t msg2block1[], int verbose);
